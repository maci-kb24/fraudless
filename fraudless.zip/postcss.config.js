export const plugins = {
  tailwindcss: {},
  autoprefixer: {},
};